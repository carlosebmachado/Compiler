file = open('file.txt', 'w')


file.write('<ascii>                 ::= ')
for i in range(0, 256):
	if i < 10:
  		file.write('#00' + str(i) + ' | ')
	elif i < 100:
  		file.write('#0' + str(i) + ' | ')
	else:
  		file.write('#' + str(i) + ' | ')


file.write('<letter>                ::= ')
for i in range(65, 91):
  	file.write('"' + chr(i) + '" | ')
for i in range(97, 123):
  	file.write('"' + chr(i) + '" | ')

file.close()
